/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

/**
 *
 * @author x14105586
 */
public class DrawSelectApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DrawSelect myDrawSelect = new DrawSelect();
        myDrawSelect.setVisible(true);
        
        /*Lotto myLotto = new Lotto();
        myLotto.setVisible(false);
        
        LottoPlus myLp = new LottoPlus();
        myLp.setVisible(false);*/
    }
    
}
